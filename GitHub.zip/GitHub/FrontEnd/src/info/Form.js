import React from 'react';
//import ReactDOM from 'react-dom';

class InfoForm extends React.Component{
    constructor(){
        super();
        
this.state = {
    _id:"",
    Name:"",
    PhoneNumber:"",
    Email:"",
    Address:"",
    isEdit:false
}
    }
    

infoChange = event => 
{
const { name,value } = event.target;

this.setState({
    [name] : value
})
}

infoSubmit = event =>
{
    if(!this.state.isEdit)
    {
        let data = {
            isEdit:this.state.isEdit,
            Name:this.state.Name,
            PhoneNumber:this.state.PhoneNumber,
            Email:this.state.Email,
            Address:this.state.Address
    }
    this.props.myData(data);
    }
    else
    {
        let data = {
            isEdit:this.state.isEdit,
            _id:this.state._id,
            Name:this.state.Name,
            PhoneNumber:this.state.PhoneNumber,
            Email:this.state.Email,
            Address:this.state.Address
    }
    this.props.myData(data);
}
}
componentWillReceiveProps(props)
{
    console.log(props.setForm)
    if(props.setForm._id != null)
    {
        this.setState({
            isEdit:true,
            _id:props.setForm._id,
            Name:props.setForm.Name,
            PhoneNumber:props.setForm.PhoneNumber,
            Email:props.setForm.Email,
            Address:props.setForm.Address
        })
    }
}

    render(){
        return(
<form onSubmit={this.infoSubmit} autoComplete="off">
  <div className="form-group">
    <label>Name: </label>
    <input type="text" className="form-control" placeholder="Enter your name" onChange={this.infoChange} name="Name" value={this.state.Name} />
  </div>
  <div className="form-group">
    <label>PhoneNumber: </label>
    <input type="Number" className="form-control" placeholder="PhoneNumber" onChange={this.infoChange} name="PhoneNumber" value={this.state.PhoneNumber} />
  </div>
  <div className="form-group">
    <label>Email: </label>
    <input type="mail" className="form-control" placeholder="abc@example.com" onChange={this.infoChange} name="Email" value={this.state.Email} />
  </div>
  <div className="form-group">
    <label>Address: </label>
    <input type="text" className="form-control" placeholder="Enter your address" onChange={this.infoChange} name="Address" value={this.state.Address} />
  </div>
        <button type="submit" className="btn btn-primary">{this.state.isEdit ? 'Update' : 'Create'}</button>
</form>
        )
    }
}

export default InfoForm;