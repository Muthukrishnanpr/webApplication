const mongoose = require("mongoose");

const infoSchema = mongoose.Schema({
    Name:{
        type:String,
        required:true,
        trim:true
    },
    PhoneNumber:{
        type:Number,
        required:true
    },
    Email:{
        type:String,
        required:true
    },
    Address:{
        type:String,
        required:true
    },
    CreateTime:{
        type:Date,
        defalut:Date.now
    }
})

module.exports = mongoose.model("info",infoSchema);