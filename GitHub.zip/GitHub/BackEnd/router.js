const express = require("express");
const infoSchema = require("./infoSchema");
const router = express.Router();
const infoRouter = require("./infoSchema");


//Create
router.post("/",async(req,res) => {
    console.log(req.body);
    var data = new infoRouter({
        Name:req.body.Name,
        PhoneNumber:req.body.PhoneNumber,
        Email:req.body.Email,
        Address:req.body.Address
    });
    await data.save();
    res.json(data);
})


//GetAll
router.get("/",async(req,res) => {
    var findData = await infoRouter.find();
    res.json(findData);
})


//Update
router.put("/update",async(req,res) => {
    var update = await infoRouter.update({_id:req.body._id},{$set:{
        Name:req.body.Name,
        PhoneNumber:req.body.PhoneNumber,
        Email:req.body.Email,
        Address:req.body.Address
    }});
    res.json(update);
})


//Delete
router.delete("/del/:id",async(req,res) => {
    var delData = await infoRouter.findByIdAndRemove(req.params.id).then(e =>{
        res.json({message:"Deleted Successfully!"})
    })
})


router.get('/',(req,res) =>{
    res.json("I am From Router File")
})

module.exports = router;